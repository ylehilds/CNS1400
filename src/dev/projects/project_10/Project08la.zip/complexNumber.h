//class ComplexNumber headre file...

#ifndef COMPLEXNUMBER_H
#define COMPLEXNUMBER_H
#include <iostream>
using namespace std;
class ComplexNumber
{
public:
ComplexNumber();
ComplexNumber(double , double);
void complex();
double getRealPart() const;
double getImaginaryPart() const;
ComplexNumber addComplexNumbers(const ComplexNumber&);
ComplexNumber subComplexNumbers(const ComplexNumber&);

private:
	double realPart;
	double imPart;
};

# endif
